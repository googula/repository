<?php
/**
 * BuddyBoss Groups Template Functions.
 *
 * @package BuddyBossPro
 * @since   1.1.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
