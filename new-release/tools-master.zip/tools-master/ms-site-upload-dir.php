<?php

/**
 * Force all network uploads to reside in "wp-content/uploads", and by-pass
 * "files" URL rewrite for site-specific directories.
 * 
 * 
 * @param   array   $dirs
 * @return  array
 */
add_filter( 'upload_dir', 'multisite_upload_dir' );

function multisite_upload_dir( $dirs ) {

    $dirs['baseurl'] = site_url('/assets/media');
    $dirs['basedir'] = $_SERVER['DOCUMENT_ROOT'] . '/assets/media';
    $dirs['path'] = $dirs['basedir'] . $dirs['subdir'];
    $dirs['url'] = $dirs['baseurl'] . $dirs['subdir'];
 
    return $dirs;
}
