<?php 
/*
 * Plugin Name: wc_social_login_all_buttons
 * Description: Changes button display based on whether user is    
 * logged in or not using [wc_social_login_all_buttons] 
 * shortcode & Add Social Login Button to wc login form
 *
*/

//Changes button display based on whether user is logged in or not using [wc_social_login_all_buttons] shortcode
function woocommerce_social_login_all_buttons_shortcode( $atts ) {
	
	// Buffer output
	ob_start();
	
	// Displays login buttons to non-logged in users with default text from settings
	woocommerce_social_login_buttons();
	
	//Displays link account buttons to logged in users
	woocommerce_social_login_link_account_buttons();
	
	// Return buffered contents
	return ob_get_clean();
}

add_shortcode( 'wc_social_login_all_buttons', 'woocommerce_social_login_all_buttons_shortcode' );

//Add Social Login Button to wc login form
function sv_wc_social_login_add_buttons_wplogin() {

	// bail in the event that the functions aren't defined to avoid errors
	if ( ! function_exists( 'wc_get_page_permalink' ) || ! function_exists( 'woocommerce_social_login_buttons' ) ) {
		return;
	}
}
	
add_action( 'login_form',    'sv_wc_social_login_add_buttons_wplogin' );
add_action( 'register_form', 'sv_wc_social_login_add_buttons_wplogin' );