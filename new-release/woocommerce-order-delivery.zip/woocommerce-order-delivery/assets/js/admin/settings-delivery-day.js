/**
 * Delivery Day Settings
 *
 * @package WC_OD
 * @since   1.5.0
 */

(function( $ ) {

	'use strict';

	$(function() {
		// The code for deleting a time frame row is handled in table-fields.js now.
	});
})( jQuery );