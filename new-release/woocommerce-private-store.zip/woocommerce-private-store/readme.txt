=== WooCommerce Private Store ===
Contributors: andykeith, barn2media
Tags: woocommerce, private, hidden, locked
Requires at least: 4.7
Tested up to: 5.4.1
Requires PHP: 5.6
Stable tag: 1.6.3
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Hide your entire WooCommerce store from the public and search engines.

== Description ==

The WooCommerce Private Store plugin lets you hide entire store from the public and search engines. The store can be
unlocked using a password.

Hides all products, categories, tags, attributes, and store pages (cart, checkout, account, etc) from the following locations:

 * Direct access via URL
 * Navigation menus
 * Widgets
 * Search results
 * XML Sitemaps

== Installation ==

1. Go to Plugins -> Add New -> Upload and select the plugin ZIP file (see link in Purchase Confirmation Email).
1. Activate the plugin
1. Enter your license key under WooCommerce -> Settings -> Products -> Private Store
1. Set your login page and enter a password

== Frequently Asked Questions ==

Please refer to [our support page](https://barn2.co.uk/our-wordpress-plugins/woocommerce-private-store-documentation-support/).

== Changelog ==

= 1.6.3 =
Release date 1 May 2020

 * Test: Compatibility with WooCommerce 4.1 and WordPress 5.4.1.
 * Dev: Added Composer support.

= 1.6.2 =
Release date 15 April 2020

 * Fix: The license key was deactivating accidentally on some websites.
 * Dev: Rename plugin helper function to wps().
 * Dev: Minor code improvements.

= 1.6.1 =
Release date 11 March 2020

 * Tested up to WooCommerce 4.0 and WordPress 5.4.

= 1.6 =
Release date 31 January 2020

 * New: store can be unlocked for specific user roles only, as well as for all logged in users.
 * New: added new Barn2 license system.

= 1.5.1 =
Release date 21 January 2020

 * Fully tested with WordPress 5.3.2 and WooCommerce 3.9.

= 1.5 =
Release date 19 December 2019

 * PHP 5.6 or greater now required!
 * Refactor codebase and update Barn2 library.
 * Tested with latest version of WordPress and WooCommerce.
 * Fix bug when plugin is activated and WooCommerce is not installed.
 * Minor updates to text and tooltips on settings page.

= 1.4.2 =
Release date 30 October 2019

 * Tested up to WordPress 5.3 and WooCommerce 3.8.
 * Update library code.

= 1.4.1 =
Release date 16 April 2019

 * Tested with WooCommerce 3.6.

= 1.4 =
Release date 10 April 2019

 * Remove account area and lost password page from protection when accessed directly. Account pages are still hidden in widgets and menus.
 * Test with latest versions of WordPress and WooCommerce.

= 1.3.8 =
Release date 21 November 2018

 * Fix: Storefront theme - hide Cart and My Account links in footer on mobiles.
 * Test with latest version of WooCommerce.

= 1.3.7 =
Release date 12 October 2018

 * Fix: Ensure all WooCommerce shortcodes are properly protected when store is locked.
 * Fix: Hide cart icon on mobiles when using Avada theme and store is locked.
 * Tweak: Minor improvements to settings page.

= 1.3.6 =
Release date 8 June 2018

 * New: Set 'no cache' constants and headers to prevent caching when the store is locked.
 * New: Added WPML config file.
 * Fix: The store is now automatically locked by default, even when there are no passwords set.
 * Tweak: Update license code and added license.txt.
 * Dev: General code restructuring and improvements.
 * Dev: Tested up to WP 4.9.6 and WC 3.4.2.

= 1.3.5 =
Release date 17 March 2018

 * Tested up to WooCommerce 3.3.3.
 * Fix: Hide cart in header in Storefront theme.
 * Tweak: Limit maximum password expiry time to a maximum of 9999 days.

= 1.3.4 =
Release date 22 January 2018

 * New: Plugin option to hide the password form for logged out users. When the 'Automatically unlock store for logged in users' option is ticked, you can now optionally hide the password entry form.
 * Tweak: Improve compatibility with Flatsome and Basel themes.
 * Tweak: Update license code.

= 1.3.3 =
Release date 18 October 2017

 * Tested with WooCommerce 3.2.1.

= 1.3.2 =
Release date 10 June 2017

 * Fix: Bug with missing PasswordHash class when logging into store.

= 1.3.1 =
Release date 18 May 2017

 * Fix: Bug in plugin settings when no password entered.
 * Tweak: Update for XStore theme.

= 1.3 =
Release date 10 May 2017

 * New: Support for multiple store passwords. You can now add additional passwords which can be used to unlock your private store.
 * Fix: Make sure error message is only displayed once on page.
 * Tweak: Move plugin settings to their own tab under WooCommerce > Settings.

= 1.2 =
Release date 10 April 2017

 * Fix: Improve compatibility with server-side caching systems, including WP Engine's EverCache.

= 1.1.1 =
Release date 24 March 2017

 * Fix: Edge case which results in a fatal PHP error when plugin is loaded before WordPress.

= 1.1 =
Release date 24 March 2017

 * New: Removed the Login Page option as the store is now automatically locked without requiring a separate page. You can still
use the [store_login] shortcode in any post, page or widget if required.
 * New: Added plugin option to unlock the store automatically if the user is logged into WordPress.
 * New: Added Password Expiry option to plugin settings to allow expiration of login cookie to be set.
 * New: Added extra plugin options for the password form - page title, password label, and placeholder option.
 * Fix: WordPress SEO sitemap cache now cleared correctly on install or activation/deactivation.

= 1.0.1 =
Release date 22 February 2017

 * Added Store Redirect option to allow customisation of the redirect page after login.

= 1.0 =
Release date 21 February 2017

* Initial release.