<?php
namespace Barn2\Plugin\WC_Private_Store;

use Barn2\WPS_Lib\Registerable,
    Barn2\WPS_Lib\Service;

/**
 * Displays and handles the login form used to unlock the store. The form is added via a shortcode.
 *
 * @package   Barn2/woocommerce-private-store
 * @author    Barn2 Plugins <info@barn2.co.uk>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Store_Login implements Registerable, Service {

    const SHORTCODE = 'store_login';

    private static $form_id = 1;

    public function register() {
        // Register login shortcode
        add_shortcode( self::SHORTCODE, array( $this, 'do_shortcode' ) );

        // Handle login when form is submitted
        add_action( 'template_redirect', array( $this, 'handle_login' ) );
    }

    public function handle_login() {
        if ( 'POST' !== $_SERVER['REQUEST_METHOD'] || ! \filter_input( \INPUT_POST, 'wcps_login', \FILTER_VALIDATE_INT ) ) {
            return;
        }

        $password = \filter_input( \INPUT_POST, 'post_password', \FILTER_SANITIZE_STRING );

        if ( ! $password ) {
            return;
        }

        if ( $this->validate_password( $password ) ) {
            // Set password cooke to 'unlock' the store
            $this->set_password_cookie( $password );

            // Redirect to the unlocked store
            $this->login_redirect();
        }
    }

    public function do_shortcode( $atts, $content = '' ) {
        $defaults = array(
            'message'          => \get_option( 'wcps_form_message', '' ),
            'unlocked_message' => __( 'The store is currently unlocked.', 'woocommerce-private-store' ),
            'visit_store'      => __( 'Visit store', 'woocommerce-private-store' )
        );

        $atts = \shortcode_atts( $defaults, $atts, self::SHORTCODE );

        foreach ( $atts as $option => $value ) {
            if ( 'false' == $atts[$option] ) {
                $atts[$option] = false;
            } elseif ( 'true' == $atts[$option] ) {
                $atts[$option] = $defaults[$option];
            }
        }

        if ( Util::store_locked() ) {
            $content = $this->get_password_form( $atts['message'] );
        } else {
            $content = $atts['unlocked_message'] ? \do_shortcode( \wpautop( $atts['unlocked_message'] ) ) : '';

            if ( $atts['visit_store'] ) {
                $store_link = \get_option( 'wcps_store_redirect' );
                if ( ! $store_link ) {
                    $store_link = \wc_get_page_permalink( 'shop' );
                }
                $content .= \sprintf( '<p class="wcps-visit-store"><a class="wcps-visit-store-link" href="%s">%s</a></p>', \esc_url( $store_link ), $atts['visit_store'] );
            }
        }

        return $content;
    }

    public function get_password_form( $message = '' ) {
        $post_id         = \get_the_ID();
        $label_id        = 'pwbox-' . ( $post_id ? $post_id : \rand() );
        $container_class = \trim( 'wcps-login-wrapper ' . \apply_filters( 'wc_private_store_form_container_class', '' ) );
        $action          = \add_query_arg( null, null );

        $message = $message ? \do_shortcode( \wpautop( $message ) ) : '';
        $message .= $this->get_error_message( self::$form_id );

        $password_label = \trim( \get_option( 'wcps_form_password_label', __( 'Password:', 'woocommerce-private-store' ) ) );
        $placeholder    = '';

        if ( $password_label ) {
            if ( 'yes' === \get_option( 'wcps_form_label_placeholder' ) ) {
                $placeholder    = ' placeholder="' . \esc_attr( $password_label ) . '"';
                $password_label = '';
            } else {
                $password_label .= ' ';
            }
        }

        $hide_form = ( 'yes' === \get_option( 'wcps_logged_in_users', 'no' ) ) && ( 'yes' === \get_option( 'wcps_hide_login_form', 'no' ) );

        \ob_start();
        \do_action( 'wc_private_store_before_login_form' );
        ?>
        <div class="<?php echo \esc_attr( $container_class ); ?>">
            <?php if ( $hide_form ) : ?>
                <?php echo $message; ?>
            <?php else : ?>
                <form action="<?php echo \esc_url( $action ); ?>" class="wcps-login-form post-password-form" method="post">
                    <?php echo $message; ?>
                    <input type="hidden" name="wcps_login" value="<?php echo \esc_attr( self::$form_id ); ?>" />
                    <p class="wcps-password-form-input">
                        <label class="wcps-password-label" for="<?php echo \esc_attr( $label_id ); ?>"><?php echo $password_label; ?><input name="post_password" id="<?php echo \esc_attr( $label_id ); ?>" type="password" size="25"<?php echo $placeholder; ?> /></label>
                        <input type="submit" name="Submit" value="<?php echo \esc_attr( \get_option( 'wcps_form_button', _x( 'Enter', 'store login button', 'woocommerce-private-store' ) ) ); ?>" />
                    </p>
                </form>
            <?php endif; ?>
        </div>
        <?php
        \do_action( 'wc_private_store_after_login_form' );

        self::$form_id ++;

        return \apply_filters( 'wc_private_store_login_form', \ob_get_clean() );
    }

    private function get_error_message( $form_id ) {
        if ( 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
            return '';
        }

        $submitted_form_id = \filter_input( \INPUT_POST, 'wcps_login', \FILTER_VALIDATE_INT );

        // Check the passed form ID matches the one in $_POST
        if ( ! $submitted_form_id || $form_id !== (int) $submitted_form_id ) {
            return '';
        }

        $error    = '';
        $password = \filter_input( \INPUT_POST, 'post_password', \FILTER_SANITIZE_STRING );

        if ( ! $password ) {
            $error = __( 'Please enter a password.', 'woocommerce-private-store' );
        } else {
            // If we have a password, and we're doing a POST request (therefore we haven't redirected), then the password must be wrong.
            $error = __( 'Incorrect password, please try again.', 'woocommerce-private-store' );
        }

        if ( $error ) {
            return \sprintf( '<p class="wcps-login-error">%s</p>', $error );
        }
        return '';
    }

    private function login_redirect() {
        $redirect = \get_option( 'wcps_store_redirect' );

        if ( ! $redirect ) {
            $redirect = \add_query_arg( null, null );
        }

        \wp_safe_redirect( \apply_filters( 'wc_private_store_login_redirect', $redirect ) );
    }

    private function set_password_cookie( $password ) {
        require_once \ABSPATH . \WPINC . '/class-phpass.php';
        $hasher = new \PasswordHash( 8, true );

        $password_expires_after = \get_option( 'wcps_password_expires', 10 );
        $expire                 = \apply_filters( 'wc_private_store_password_expires', \time() + $password_expires_after * \DAY_IN_SECONDS );
        $referer                = \wp_get_referer();

        if ( $referer ) {
            $secure = ( 'https' === \parse_url( $referer, \PHP_URL_SCHEME ) );
        } else {
            $secure = false;
        }

        \setcookie( \WCPS_COOKIE_PREFIX . \COOKIEHASH, $hasher->HashPassword( \wp_unslash( $password ) ), $expire, \COOKIEPATH, \COOKIE_DOMAIN, $secure );
    }

    private function validate_password( $password ) {
        return $password && \in_array( $password, (array) \get_option( 'wcps_store_password' ) );
    }

}
