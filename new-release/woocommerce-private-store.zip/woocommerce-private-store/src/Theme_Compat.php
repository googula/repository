<?php

namespace Barn2\Plugin\WC_Private_Store;

use Barn2\WPS_Lib\Registerable,
    Barn2\WPS_Lib\Service;

/**
 * Theme-specific overrides for WooCommerce Private Store.
 *
 * @package   Barn2/woocommerce-private-store
 * @author    Barn2 Plugins <info@barn2.co.uk>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Theme_Compat implements Registerable, Service {

    public function register() {
        if ( Util::store_locked() ) {
            \add_action( 'setup_theme', [ $this, 'theme_function_overrides' ] );
            \add_action( 'after_setup_theme', [ $this, 'after_setup_theme' ] );
            \add_action( 'init', [ $this, 'init' ], 50 );
            \add_filter( 'body_class', [ $this, 'body_class' ] );
        }
    }

    public function theme_function_overrides() {
        require_once __DIR__ . '/theme-function-overrides.php';
    }

    /**
     * Hooks run on 'after_setup_theme'.
     */
    public function after_setup_theme() {
        // Avada
        \remove_filter( 'wp_nav_menu_items', 'avada_add_login_box_to_nav', 10 );

        // Bridge
        \remove_shortcode( 'product_list_elegant' );
        \remove_shortcode( 'product_list_masonry' );
        \remove_shortcode( 'product_list_pinterest' );

        // Storefront
        \remove_action( 'storefront_header', 'storefront_header_cart', 60 );
        \add_filter( 'storefront_handheld_footer_bar_links', [ $this, 'storefront_hide_cart_in_handheld_footer_bar' ] );

        // Loom
        \remove_filter( 'wp_nav_menu_items', 'ebor_cart_icon', 20 );

        // Total
        \remove_filter( 'wp_nav_menu_items', [ 'WPEX_WooCommerce_Config', 'menu_cart_icon' ], 10 );

        // X
        \remove_filter( 'wp_nav_menu_items', 'x_woocommerce_navbar_menu_item', 9999 );
    }

    /**
     * Hooks run on 'init'.
     */
    public function init() {
        // Enfold
        \remove_action( 'ava_main_header', 'avia_woocommerce_cart_dropdown', 10 );
        \remove_action( 'ava_inside_main_menu', 'avia_woocommerce_cart_dropdown', 10 );
        \remove_action( 'ava_before_bottom_main_menu', 'avia_woocommerce_cart_dropdown', 10 );
    }

    public function body_class( $classes ) {
        $classes[] = 'woocommerce-locked';
        return $classes;
    }

    public function storefront_hide_cart_in_handheld_footer_bar( $links ) {
        unset( $links['cart'] );
        unset( $links['my-account'] );
        return $links;
    }

}
