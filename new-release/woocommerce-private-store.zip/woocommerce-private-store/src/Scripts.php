<?php

namespace Barn2\Plugin\WC_Private_Store;

use Barn2\WPS_Lib\Registerable,
    Barn2\WPS_Lib\Service,
    Barn2\WPS_Lib\Util as Lib_Util;

/**
 * Loads the front-end scripts and styles.
 *
 * @package   Barn2/woocommerce-private-store
 * @author    Barn2 Plugins <info@barn2.co.uk>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Scripts implements Registerable, Service {

    private $file;
    private $version;

    public function __construct( $file, $version ) {
        $this->file    = $file;
        $this->version = $version;
    }

    public function register() {
        \add_action( 'wp_enqueue_scripts', [ $this, 'load_scripts' ] );
    }

    public function load_scripts() {
        $min = Lib_Util::get_script_suffix();
        \wp_enqueue_style( 'wc-private-store', \plugins_url( "assets/css/wc-private-store{$min}.css", $this->file ), [], $this->version );
    }

}
