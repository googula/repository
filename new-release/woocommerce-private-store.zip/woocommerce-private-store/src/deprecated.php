<?php

// Prevent direct file access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WC_Private_Store_Plugin {

    public static function instance() {
        _deprecated_function( __METHOD__, '1.5', 'Barn2\Plugin\WC_Private_Store\wps()' );
        return Barn2\Plugin\WC_Private_Store\wps();
    }

}

class WCPS_Util {

    public static function __callStatic( $method, $args ) {
        if ( method_exists( 'Barn2\Plugin\WC_Private_Store\Util', $method ) ) {
            _deprecated_function( "WCPS_Util::{$method}", '1.5', "Barn2\Plugin\WC_Private_Store\Util::{$method}" );
            return Barn2\Plugin\WC_Private_Store\Util::$method( $args );
        }
    }

}

class WC_Private_Store_Login {

    const SHORTCODE = 'store_login';

    public static function instance() {
        _deprecated_function( __METHOD__, '1.5', "Barn2\Plugin\WC_Private_Store\wps()->get_service( 'store_login' )" );
        return self::store_login_service();
    }

    public function handle_login() {
        _deprecated_function( __METHOD__, '1.5', 'Barn2\Plugin\WC_Private_Store\Store_Login::handle_login()' );
        self::store_login_service()->handle_login();
    }

    public function get_password_form( $message = '' ) {
        _deprecated_function( __METHOD__, '1.5', 'Barn2\Plugin\WC_Private_Store\Store_Login::get_password_form()' );
        self::store_login_service()->get_password_form( $message );
    }

    public function do_shortcode( $atts, $content = '' ) {
        _deprecated_function( __METHOD__, '1.5', 'Barn2\Plugin\WC_Private_Store\Store_Login::do_shortcode()' );
        self::store_login_service()->do_shortcode( $atts, $content );
    }

    private static function store_login_service() {
        return Barn2\Plugin\WC_Private_Store\wps()->get_service( 'store_login' );
    }

}

class WC_Private_Store_Protecter {

    public static function instance() {
        _deprecated_function( __METHOD__, '1.5', "Barn2\Plugin\WC_Private_Store\wps()->get_service( 'store_protector' )" );
        return self::store_protector_service();
    }

    public function __call( $method, $args ) {
        if ( method_exists( 'Barn2\Plugin\WC_Private_Store\Store_Protector', $method ) ) {
            _deprecated_function( "WC_Private_Store_Protecter{$method}", '1.5', "Barn2\Plugin\WC_Private_Store\Store_Protector::{$method}" );
            return self::store_protector_service()->$method( $args );
        }
    }

    private static function store_protector_service() {
        return Barn2\Plugin\WC_Private_Store\wps()->get_service( 'store_protector' );
    }

}
