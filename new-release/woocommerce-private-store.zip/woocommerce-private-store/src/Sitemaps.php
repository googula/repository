<?php

namespace Barn2\Plugin\WC_Private_Store;

use Barn2\WPS_Lib\Registerable,
    Barn2\WPS_Lib\Service;

/**
 * Protection for XML sitemaps.
 *
 * @package   Barn2/woocommerce-private-store
 * @author    Barn2 Plugins <info@barn2.co.uk>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Sitemaps implements Registerable, Service {

    public function register() {
        self::protect();
    }

    public static function protect() {
        // All in One SEO Pack
        if ( \defined( 'AIOSEOP_VERSION' ) && ! \is_admin() ) {
            \add_filter( 'option_aioseop_options', array( __CLASS__, 'aioseop_excludes' ) );
        }

        // WordPress SEO
        \add_action( 'admin_init', array( __CLASS__, 'wpseo_maybe_clear_cache' ) );

        if ( \defined( 'WPSEO_VERSION' ) ) {
            // Maybe clear sitemap cache (cache_1 = root sitemap)
            \add_action( 'wpseo_sitemap_stylesheet_cache_1', array( __CLASS__, 'wpseo_maybe_clear_root_cache' ) );

            // Always clear sitemap cache if product stuff is accessed
            \add_action( 'wpseo_sitemap_stylesheet_cache_product', array( __CLASS__, 'clear_wpseo_sitemap_cache' ) );
            \add_action( 'wpseo_sitemap_stylesheet_cache_product_cat', array( __CLASS__, 'clear_wpseo_sitemap_cache' ) );
            \add_action( 'wpseo_sitemap_stylesheet_cache_product_tag', array( __CLASS__, 'clear_wpseo_sitemap_cache' ) );

            // Add store pages to excluded-posts option in WP SEO
            \add_filter( 'option_wpseo_xml', array( __CLASS__, 'wpseo_exclude_store_pages' ) );

            // Prevent products and product taxonomies being added to sitemap
            \add_filter( 'wpseo_sitemap_exclude_post_type', array( __CLASS__, 'wpseo_exclude_products' ), 10, 2 );
            \add_filter( 'wpseo_sitemap_exclude_taxonomy', array( __CLASS__, 'wpseo_exclude_taxonomies' ), 10, 2 );
        }

        //@todo: Other sitemap plugins
    }

    public static function aioseop_excludes( $value ) {

        if ( ! \is_admin() && isset( $value['modules']['aiosp_sitemap_options'] ) ) {
            $sitemap_options = $value['modules']['aiosp_sitemap_options'];

            // Remove product post type
            if ( ! empty( $sitemap_options['aiosp_sitemap_posttypes'] ) && \is_array( $sitemap_options['aiosp_sitemap_posttypes'] ) && $product = \array_search( 'product', $sitemap_options['aiosp_sitemap_posttypes'] ) ) {
                unset( $sitemap_options['aiosp_sitemap_posttypes'][$product] );
                $sitemap_options['aiosp_sitemap_posttypes'] = \array_values( $sitemap_options['aiosp_sitemap_posttypes'] );
            }

            // Remove product taxonomies
            if ( ! empty( $sitemap_options['aiosp_sitemap_taxonomies'] ) && \is_array( $sitemap_options['aiosp_sitemap_taxonomies'] ) ) {
                $sitemap_options['aiosp_sitemap_taxonomies'] = \array_values( \array_diff( $sitemap_options['aiosp_sitemap_taxonomies'], \get_object_taxonomies( 'product' ) ) );
            }

            // Remove store pages
            if ( isset( $sitemap_options['aiosp_sitemap_excl_pages'] ) ) {
                $excludes = Util::wc_store_page_ids();

                if ( ! empty( $sitemap_options['aiosp_sitemap_excl_pages'] ) ) {
                    $curr_excludes = \explode( ',', \str_replace( ' ', '', $sitemap_options['aiosp_sitemap_excl_pages'] ) );
                    $excludes      = \array_unique( \array_merge( $excludes, $curr_excludes ) );
                }
                $sitemap_options['aiosp_sitemap_excl_pages'] = \implode( ',', $excludes );
            }

            $value['modules']['aiosp_sitemap_options'] = $sitemap_options;
        }

        return $value;
    }

    public static function aioseo_exclude_products_and_shop( $query_args ) {

        if ( ! empty( $query_args['post_type'] ) ) {
            if ( \is_array( $query_args['post_type'] ) && $product = \array_search( 'product', $query_args['post_type'] ) ) {
                unset( $query_args['post_type'][$product] );
            } elseif ( 'any' === $query_args['post_type'] ) {
                $query_args['post_type'] = \get_post_types( array( 'name' => 'product' ), 'names', 'not' );
            }
        }

        return $query_args;
    }

    public static function wpseo_maybe_clear_cache() {
        $cache_cleared = \get_option( 'wcps_wpseo_cache_cleared' );

        // Clear WPSEO cache once when WCPS is first run. If WPSEO is later deactivated, reset option.
        if ( \defined( 'WPSEO_VERSION' ) ) {
            if ( ! $cache_cleared ) {
                self::clear_wpseo_sitemap_cache();
                \add_option( 'wcps_wpseo_cache_cleared', true );
            }
        } elseif ( $cache_cleared ) {
            \delete_option( 'wcps_wpseo_cache_cleared' );
        }
    }

    public static function wpseo_maybe_clear_root_cache() {
        // Remove WooCommerce types from current sitemap cache
        global $wpseo_sitemaps;

        // Get root sitemap
        $cached_sitemap = $wpseo_sitemaps->cache->get_sitemap_data( '1', 1 );

        if ( $cached_sitemap && \strpos( $cached_sitemap->get_sitemap(), 'product-sitemap.xml' ) ) {
            self::clear_wpseo_sitemap_cache();
        }
    }

    public static function clear_wpseo_sitemap_cache() {
        if ( \class_exists( '\WPSEO_Sitemaps_Cache_Validator' ) ) {
            \WPSEO_Sitemaps_Cache_Validator::invalidate_storage();
        }
    }

    public static function wpseo_exclude_store_pages( $value ) {
        if ( ! \is_admin() && isset( $value['excluded-posts'] ) ) {
            $exclude                 = $value['excluded-posts'] ? \explode( ',', $value['excluded-posts'] ) : array();
            $value['excluded-posts'] = \implode( ',', \array_unique( \array_merge( $exclude, Util::wc_store_page_ids() ) ) );
        }
        return $value;
    }

    public static function wpseo_exclude_products( $exclude, $post_type ) {
        if ( 'product' === $post_type ) {
            return true;
        }
        return $exclude;
    }

    public static function wpseo_exclude_taxonomies( $exclude, $taxonomy ) {
        if ( \in_array( $taxonomy, \get_object_taxonomies( 'product' ) ) ) {
            return true;
        }
        return $exclude;
    }

}
