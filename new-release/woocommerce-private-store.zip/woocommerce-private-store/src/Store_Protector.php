<?php

namespace Barn2\Plugin\WC_Private_Store;

use Barn2\WPS_Lib\Registerable,
    Barn2\WPS_Lib\Service;

/**
 * This class provides the main functions to lock down the entire store on the front end.
 *
 * This includes locking down the store pages, products, categories, tags, etc, as well
 * as hiding items from navigations menus, removing WooCommerce widgets, and hiding from search results.
 *
 * @package   Barn2/woocommerce-private-store
 * @author    Barn2 Plugins <info@barn2.co.uk>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Store_Protector implements Registerable, Service {

    private $is_protected_page = null;

    public function register() {
        add_action( 'wp_loaded', array( $this, 'protect' ) );
    }

    public function protect() {
        if ( ! Util::store_locked() ) {
            return;
        }

        // Prevent caching and search indexing if showing protected store page - done on 'wp' hook as certain caching plugins require this.
        \add_action( 'wp', array( $this, 'maybe_prevent_caching' ) );

        // Protect store pages (shop, products, taxonomies, etc) - late priority so we run after WC_Template_Loader::unsupported_theme_init().
        \add_action( 'template_redirect', array( $this, 'maybe_protect_store_page' ), 100 );

        // Hide WooCommerce widgets
        \add_filter( 'sidebars_widgets', array( $this, 'protect_widgets' ), 100 );

        // Hide WC pages in Pages widget
        \add_filter( 'wp_list_pages_excludes', array( $this, 'hide_store_in_pages_widget' ) );

        // Remove hidden categories and/or products in nav menus
        \add_filter( 'wp_get_nav_menu_items', array( $this, 'protect_nav_menus' ), 10, 3 );

        // Exclude store pages from search
        \add_action( 'pre_get_posts', array( $this, 'hide_store_in_search' ) );

        // Exclude products from search
        \add_filter( 'posts_where', array( $this, 'hide_products_in_search' ), 10, 2 );

        // Remove and replace WooCommerce shortcodes
        $this->replace_shortcodes();
    }

    public function maybe_prevent_caching() {
        if ( $this->is_protected_page() ) {
            $this->prevent_caching();
            $this->prevent_indexing();
        }
    }

    public function maybe_protect_store_page() {
        if ( $this->is_protected_page() ) {
            $this->show_protected_page_content();
        }
    }

    public function protect_widgets( $sidebars_widgets ) {

        if ( ! $sidebars_widgets || ! \is_array( $sidebars_widgets ) ) {
            return $sidebars_widgets;
        }

        foreach ( $sidebars_widgets as $sidebar_id => $widgets ) {
            if ( $widgets && \is_array( $widgets ) ) {
                $sidebars_widgets[$sidebar_id] = \array_values( \array_filter( \preg_replace( '/^woocommerce.*|^uncode_wc.*/i', '', $widgets ) ) );
            }
        }

        return $sidebars_widgets;
    }

    public function hide_store_in_pages_widget( $excludes ) {
        return \array_unique( \array_merge( $excludes, Util::wc_store_page_ids() ) );
    }

    public function protect_nav_menus( $menu_items, $menu, $args ) {
        $removed_items = array();

        foreach ( $menu_items as $key => $menu_item ) {
            // Remove menu item if it's a product, product taxonomy or WooCommerce page
            if ( \in_array( $menu_item->object, Util::wc_object_types() ) ||
                $this->is_wc_endpoint( $menu_item->post_name ) ||
                ( 'page' === $menu_item->object && \in_array( $menu_item->object_id, Util::wc_store_page_ids() ) ) ) {
                $removed_items[] = $menu_item->ID;
                unset( $menu_items[$key] );
            }
        }

        // Now find and remove any children of any removed menu item
        while ( $removed_items ) {
            $child_items_removed = array();

            foreach ( $menu_items as $key => $menu_item ) {
                if ( \in_array( $menu_item->menu_item_parent, $removed_items ) ) {
                    $child_items_removed[] = $menu_item->ID;
                    unset( $menu_items[$key] );
                }
            }

            // Update the removed list with the removed child items and start over
            $removed_items = $child_items_removed;
        }

        return \array_values( $menu_items );
    }

    public function hide_store_in_search( &$query ) {
        if ( ! $query->is_search ) {
            return;
        }

        $exclude = isset( $query->query_vars['post__not_in'] ) ? $query->query_vars['post__not_in'] : array();

        $query->query_vars['post__not_in'] = \array_unique( \array_merge( $exclude, Util::wc_store_page_ids() ) );
    }

    public function hide_products_in_search( $where, $query ) {
        if ( ! $query->is_search ) {
            return $where;
        }

        global $wpdb;
        $matches = array();

        if ( \preg_match( "/{$wpdb->posts}.post_type IN \((.+)\)/iU", $where, $matches ) && ! empty( $matches[1] ) ) {

            $post_types  = \array_diff( \explode( ', ', $matches[1] ), array( 'product', "'product'" ) );
            $replacement = $post_types ? \sprintf( "{$wpdb->posts}.post_type IN (%s)", \implode( ', ', $post_types ) ) : '';

            $where = \preg_replace( "/{$wpdb->posts}.post_type IN \(.+\)/iU", $replacement, $where );
        } else {
            $where = \str_replace( " AND {$wpdb->posts}.post_type = 'product'", '', $where );

            if ( false === \strpos( $where, "{$wpdb->posts}.post_type" ) ) {
                $where .= " AND {$wpdb->posts}.post_type <> 'product'";
            }
        }
        return $where;
    }

    private function replace_shortcodes() {
        $shortcodes = array(
            'product',
            'product_page',
            'product_category',
            'product_categories',
            'add_to_cart',
            'add_to_cart_url',
            'products',
            'recent_products',
            'sale_products',
            'best_selling_products',
            'top_rated_products',
            'featured_products',
            'product_attribute',
            'related_products',
            'shop_messages',
            'woocommerce_order_tracking',
            'woocommerce_cart',
            'woocommerce_checkout',
            'product_table'
        );

        foreach ( $shortcodes as $shortcode ) {
            \remove_shortcode( $shortcode );
            \add_shortcode( $shortcode, array( __CLASS__, 'empty_shortcode' ) );
        }
    }

    private function prevent_caching() {
        // Set headers to prevent caching
        \nocache_headers();

        // Set constants to prevent caching in cache plugins
        if ( ! \defined( 'DONOTCACHEPAGE' ) ) {
            \define( 'DONOTCACHEPAGE', true );
        }
        if ( ! \defined( 'DONOTCACHEOBJECT' ) ) {
            \define( 'DONOTCACHEOBJECT', true );
        }
        if ( ! \defined( 'DONOTCACHEDB' ) ) {
            \define( 'DONOTCACHEDB', true );
        }
    }

    private function prevent_indexing() {
        @header( 'X-Robots-Tag: noindex, nofollow' );
        \add_action( 'wp_head', array( $this, 'meta_robots_noindex_head' ), 5 );
    }

    public function meta_robots_noindex_head() {
        echo '<meta name="robots" content="noindex, nofollow" />' . "\n";
    }

    private function show_protected_page_content() {
        global $wp, $wp_query;

        // Spoof main WP query with dummy page which holds our login shortcode
        $post_id              = 0; // to avoid clash with a valid post
        $post                 = new \stdClass();
        $post->ID             = $post_id;
        $post->post_author    = 1;
        $post->post_date      = \current_time( 'mysql' );
        $post->post_date_gmt  = \current_time( 'mysql', 1 );
        $post->post_title     = \get_option( 'wcps_login_title', __( 'Store Login', 'woocommerce-private-store' ) );
        $post->post_content   = '[' . Store_Login::SHORTCODE . ']';
        $post->post_status    = 'publish';
        $post->comment_status = 'closed';
        $post->ping_status    = 'closed';
        $post->post_name      = 'store-login-' . \rand( 1, 99999 ); // append random number to avoid clash
        $post->post_type      = 'page';
        $post->filter         = 'raw'; // important
        // Convert to WP_Post object
        $wp_post              = new \WP_Post( $post );

        // Add our fake post to the cache
        \wp_cache_add( $post_id, $wp_post, 'posts' );
        \wp_cache_add( $post_id, array( true ), 'post_meta' );

        // Update main query
        $wp_query->post                 = $wp_post;
        $wp_query->posts                = array( $wp_post );
        $wp_query->queried_object       = $wp_post;
        $wp_query->queried_object_id    = $post_id;
        $wp_query->found_posts          = 1;
        $wp_query->post_count           = 1;
        $wp_query->max_num_pages        = 1;
        $wp_query->is_page              = true;
        $wp_query->is_singular          = true;
        $wp_query->is_single            = false;
        $wp_query->is_attachment        = false;
        $wp_query->is_archive           = false;
        $wp_query->is_category          = false;
        $wp_query->is_tag               = false;
        $wp_query->is_tax               = false;
        $wp_query->is_author            = false;
        $wp_query->is_date              = false;
        $wp_query->is_year              = false;
        $wp_query->is_month             = false;
        $wp_query->is_day               = false;
        $wp_query->is_time              = false;
        $wp_query->is_search            = false;
        $wp_query->is_feed              = false;
        $wp_query->is_comment_feed      = false;
        $wp_query->is_trackback         = false;
        $wp_query->is_home              = false;
        $wp_query->is_embed             = false;
        $wp_query->is_404               = false;
        $wp_query->is_paged             = false;
        $wp_query->is_admin             = false;
        $wp_query->is_preview           = false;
        $wp_query->is_robots            = false;
        $wp_query->is_posts_page        = false;
        $wp_query->is_post_type_archive = false;

        // Update globals
        $GLOBALS['wp_query'] = $wp_query;
        $wp->register_globals();
    }

    private function is_wc_endpoint( $endpoint ) {
        $wc_endpoints = \WC()->query->get_query_vars();

        if ( $wc_endpoints && isset( $wc_endpoints[$endpoint] ) ) {
            return true;
        }
        return false;
    }

    private function is_protected_page() {
        global $post;

        if ( ! \did_action( 'parse_query' ) ) {
            return false;
        }

        if ( null !== $this->is_protected_page ) {
            return $this->is_protected_page;
        }

        $is_protected = \is_shop() || \is_product() || \is_product_taxonomy() || \is_cart() || \is_checkout() || ( $post && $post->ID === \wc_get_page_id( 'terms' ) );

        $this->is_protected_page = \apply_filters( 'wc_private_store_is_protected_page', $is_protected );
        return $this->is_protected_page;
    }

    public static function empty_shortcode( $atts = array() ) {
        return '';
    }

}
