<?php

// Prevent direct file access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Theme-specific function overrides.
 *
 * If the store is currently locked, this file is included to override theme functions, to
 * prevent WooCommerce elements being displayed (e.g. cart icon in nav menu).
 *
 * @package   Barn2/woocommerce-private-store
 * @author    Barn2 Plugins <info@barn2.co.uk>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
// Avada
if ( ! function_exists( 'avada_nav_woo_cart' ) ) {

    function avada_nav_woo_cart( $position = 'main' ) {
        // do nothing
    }

}

// Kallyas
if ( ! function_exists( 'zn_woocomerce_cart' ) ) {

    function zn_woocomerce_cart() {
        // do nothing
    }

}

// Divi
if ( ! function_exists( 'et_show_cart_total' ) ) {

    function et_show_cart_total( $args = array() ) {
        // do nothing
    }

}

// Storefront
if ( ! function_exists( 'storefront_is_woocommerce_activated' ) ) {

    function storefront_is_woocommerce_activated() {
        if ( ! Barn2\WPS_Lib\Util::is_woocommerce_active() || is_404() ) {
            return false;
        }
        return true;
    }

}


