<?php

namespace Barn2\Plugin\WC_Private_Store;

use Barn2\WPS_Lib\Registerable,
    Barn2\WPS_Lib\Translatable,
    Barn2\WPS_Lib\Service_Provider,
    Barn2\WPS_Lib\Plugin\Premium_Plugin,
    Barn2\WPS_Lib\Plugin\Licensed_Plugin,
    Barn2\WPS_Lib\Util as Lib_Util;

/**
 * The main plugin class. Responsible for setting up to core plugin services.
 *
 * @package   Barn2/woocommerce-private-store
 * @author    Barn2 Plugins <info@barn2.co.uk>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Plugin extends Premium_Plugin implements Licensed_Plugin, Registerable, Translatable, Service_Provider {

    const NAME    = 'WooCommerce Private Store';
    const ITEM_ID = 15809;

    private $services = [];

    /**
     * Constructs and initalizes the main plugin class.
     *
     * @param string $file The main plugin file.
     * @param string $version The current plugin version.
     */
    public function __construct( $file = null, $version = '1.0' ) {
        parent::__construct( [
            'name'               => self::NAME,
            'item_id'            => self::ITEM_ID,
            'version'            => $version,
            'file'               => $file,
            'is_woocommerce'     => true,
            'settings_path'      => 'admin.php?page=wc-settings&tab=private-store',
            'documentation_path' => 'kb-categories/woo-private-store-kb/',
            'legacy_db_prefix'   => 'wcps'
        ] );

        $this->define_constants();
    }

    /**
     * Registers the plugin with WordPress.
     */
    public function register() {
        parent::register();

        \add_action( 'plugins_loaded', [ $this, 'load_services' ] );
        \add_action( 'init', [ $this, 'load_textdomain' ] );
    }

    public function load_services() {
        // Don't load anything if WooCommerce not active.
        if ( ! Lib_Util::is_woocommerce_active() ) {
            $this->add_missing_woocommerce_notice();
            return;
        }

        // Create the admin service.
        if ( Lib_Util::is_admin() ) {
            $this->services['admin'] = new Admin\Admin_Controller( $this, $this->get_license_setting() );
        }

        // Create core services if license is valid.
        if ( $this->get_license()->is_valid() ) {
            $this->services['sitemaps']     = new Sitemaps();
            $this->services['scripts']      = new Scripts( $this->get_file(), $this->get_version() );
            $this->services['theme_compat'] = new Theme_Compat();

            if ( Lib_Util::is_front_end() ) {
                $this->services['store_protector'] = new Store_Protector();
                $this->services['store_login']     = new Store_Login();
            }
        }

        Lib_Util::register_services( $this->services );
    }

    public function get_service( $id ) {
        return isset( $this->services[$id] ) ? $this->services['id'] : null;
    }

    public function get_services() {
        return $this->services;
    }

    public function load_textdomain() {
        \load_plugin_textdomain( 'woocommerce-private-store', false, $this->get_slug() . '/languages' );
    }

    private function define_constants() {
        if ( ! \defined( 'WCPS_COOKIE_PREFIX' ) ) {
            // Cookie has to be same one used by WP for password protected posts, as all caching plugins exclude it.
            \define( 'WCPS_COOKIE_PREFIX', 'wp-postpass_' );
        }
    }

    private function add_missing_woocommerce_notice() {
        if ( Lib_Util::is_admin() ) {
            $admin_notice = new \Barn2\WPS_Lib\Admin\Notices();
            $admin_notice->add(
                'wps_woocommerce_missing',
                '',
                \sprintf( __( 'Please %1$sinstall WooCommerce%2$s in order to use WooCommerce Private Store.', 'woocommerce-private-store' ), Lib_Util::format_link_open( 'https://woocommerce.com/', true ), '</a>' ),
                array(
                    'type'       => 'error',
                    'capability' => 'install_plugins'
            ) );
            $admin_notice->boot();
        }
    }

}
