<?php

namespace Barn2\Plugin\WC_Private_Store;

/**
 * Utility functions for WooCommerce Private Store.
 *
 * @package   Barn2/woocommerce-private-store
 * @author    Barn2 Plugins <info@barn2.co.uk>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Util {

    public static function array_filter_positive_int( $array ) {
        if ( ! $array || ! \is_array( $array ) ) {
            return $array;
        }

        $r = \array_filter( $array, array( __CLASS__, 'filter_var_positive_int' ) );
        return $r ? \array_values( $r ) : array();
    }

    public static function filter_var_positive_int( $var ) {
        return \filter_var( $var, \FILTER_VALIDATE_INT, array( 'options' => array( 'min_range' => 0 ) ) );
    }

    public static function store_locked() {
        $locked              = true;
        $store_passwords     = (array) \get_option( 'wcps_store_password' );
        $unlock_if_logged_in = 'yes' === \get_option( 'wcps_logged_in_users' );
        $user_logged_in      = \function_exists( '\is_user_logged_in' ) && \is_user_logged_in();

        if ( $unlock_if_logged_in && $user_logged_in ) {
            $user_roles = \get_option( 'wcps_logged_in_roles' );

            if ( $user_roles ) {
                $user   = wp_get_current_user();
                // If there's role overlap, the current user has at least one of the required roles, so store is unlocked.
                $locked = ( count( array_intersect( $user->roles, $user_roles ) ) === 0 );
            } else {
                // No roles selected, so unlock for all roles.
                $locked = false;
            }
        }

        if ( $locked && $store_passwords && ( $cookie = \filter_input( \INPUT_COOKIE, \WCPS_COOKIE_PREFIX . \COOKIEHASH ) ) ) {
            $hash = \wp_unslash( $cookie );

            if ( 0 === \strpos( $hash, '$P$B' ) ) {
                require_once \ABSPATH . \WPINC . '/class-phpass.php';
                $hasher = new \PasswordHash( 8, true );

                foreach ( $store_passwords as $password ) {
                    if ( $hasher->CheckPassword( $password, $hash ) ) {
                        $locked = false;
                        break;
                    }
                }
            }
        }

        return \apply_filters( 'wc_private_store_lock_override', $locked );
    }

    public static function wc_store_page_ids() {
        return self::array_filter_positive_int(
                array( \wc_get_page_id( 'shop' ), \wc_get_page_id( 'cart' ), \wc_get_page_id( 'checkout' ), \wc_get_page_id( 'myaccount' ), \wc_get_page_id( 'terms' ) )
        );
    }

    public static function wc_object_types() {
        return \array_merge( array( 'product' ), \get_object_taxonomies( 'product' ) );
    }

}
