<?php

namespace Barn2\Plugin\WC_Private_Store\Admin;

use Barn2\WPS_Lib\Registerable,
    Barn2\WPS_Lib\Util as Lib_Util,
    Barn2\WPS_Lib\Plugin\Licensed_Plugin;

// Bail if WooCommerce class not found.
if ( ! class_exists( '\WC_Settings_Page' ) ) {
    return;
}

/**
 * The Private Store settings page. Appears under the main WooCommerce -> Settings menu.
 *
 * @package   Barn2/woocommerce-private-store
 * @author    Barn2 Plugins <info@barn2.co.uk>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Settings_Page extends \WC_Settings_Page implements Registerable {

    private $plugin;
    private $license_setting;

    public function __construct( Licensed_Plugin $plugin ) {
        $this->id    = 'private-store';
        $this->label = __( 'Private Store', 'woocommerce-private-store' );

        $this->plugin          = $plugin;
        $this->license_setting = $plugin->get_license_setting();

        // Call parent constructor last as it registers actions using $this->id
        parent::__construct();
    }

    public function register() {
        // Register custom field types.
        if ( method_exists( '\WC_Settings_Additional_Field_Types', 'register_settings' ) ) {
            \WC_Settings_Additional_Field_Types::register_settings();
        } else {
            //@todo: Remove this once all plugins are on latest version of library.
            foreach ( array( 'hidden', 'multi_text', 'settings_start', 'settings_end' ) as $field ) {
                \add_action( "woocommerce_admin_field_{$field}", array( '\WC_Settings_Additional_Field_Types', "{$field}_field" ) );
            }
        }

        // Sanitize options on save.
        \add_filter( 'woocommerce_admin_settings_sanitize_option', array( $this, 'sanitize_options' ), 10, 3 );

        // Add plugin promo.
        if ( \class_exists( '\WC_Barn2_Plugin_Promo' ) ) {
            $plugin_promo = new \WC_Barn2_Plugin_Promo( $this->plugin->get_item_id(), $this->plugin->get_file(), $this->get_id(), true );
            $plugin_promo->register();
        }
    }

    public function get_settings() {
        $settings = array(
            array(
                'id'    => 'private_store_settings_start',
                'type'  => 'settings_start',
                'class' => 'private-store-settings barn2-settings'
            ),
            array(
                'name' => __( 'Private Store', 'woocommerce-private-store' ),
                'type' => 'title',
                'desc' => '<p>' . __( 'The following options control the WooCommerce Private Store extension.', 'woocommerce-private-store' ) . '</p>' .
                '<p>' .
                Lib_Util::format_link( $this->plugin->get_documentation_url(), __( 'Documentation', 'woocommerce-private-store' ) ) . ' | ' .
                Lib_Util::format_link( $this->plugin->get_support_url(), __( 'Support', 'woocommerce-private-store' ) ) .
                '</p>',
                'id'   => 'private_store_options'
            ),
            $this->license_setting->get_license_key_setting(),
            $this->license_setting->get_license_override_setting(),
            array(
                'title'    => __( 'Store passwords', 'woocommerce-private-store' ),
                'desc_tip' => __( 'The password which will unlock your store. Use the "+" icon to add multiple passwords.', 'woocommerce-private-store' ),
                'id'       => 'wcps_store_password',
                'type'     => 'multi_text',
                'default'  => 'password123'
            ),
            array(
                'title'             => __( 'Password valid for', 'woocommerce-private-store' ),
                'desc_tip'          => __( 'The number of days the store remains unlocked for each user after entering the password.', 'woocommerce-private-store' ),
                'desc'              => __( 'days', 'woocommerce-private-store' ),
                'id'                => 'wcps_password_expires',
                'type'              => 'number',
                'default'           => 10,
                'custom_attributes' => array( 'min' => 1, 'max' => 9999 ),
                'class'             => 'password-expiry',
                'css'               => 'width:80px'
            ),
            array(
                'title'       => __( 'Redirect URL', 'woocommerce-private-store' ),
                'desc_tip'    => __( 'Redirect the user to a specific page after unlocking the store.', 'woocommerce-private-store' ),
                'id'          => 'wcps_store_redirect',
                'placeholder' => 'https://',
                'class'       => 'regular-input',
                'type'        => 'text'
            ),
            array(
                'title'             => __( 'Logged in users', 'woocommerce-private-store' ),
                'desc'              => __( 'Automatically unlock the store for logged in users', 'woocommerce-private-store' ),
                'id'                => 'wcps_logged_in_users',
                'type'              => 'checkbox',
                'default'           => 'no',
                'checkboxgroup'     => 'start',
                'show_if_checked'   => 'option',
                'class'             => 'toggle-parent',
                'custom_attributes' => array(
                    'data-child-class' => 'logged-in'
                )
            ),
            array(
                'id'              => 'wcps_hide_login_form',
                'type'            => 'checkbox',
                'desc'            => __( 'Hide the Login Form so only logged in users can access the store', 'woocommerce-private-store' ),
                'desc_tip'        => __( 'The message entered below will still be displayed.', 'woocommerce-private-store' ),
                'default'         => 'no',
                'checkboxgroup'   => 'end',
                'show_if_checked' => 'yes'
            ),
            array(
                'desc'        => __( 'Unlock for the above roles only.', 'woocommerce-private-store' ),
                'id'          => 'wcps_logged_in_roles',
                'type'        => 'multiselect',
                'options'     => \wp_list_pluck( wp_roles()->roles, 'name' ),
                'placeholder' => 'All roles',
                'class'       => 'logged-in'
            ),
            array(
                'type' => 'sectionend',
                'id'   => 'private_store_options'
            ),
            array(
                'title' => __( 'Login Form', 'woocommerce-private-store' ),
                'type'  => 'title',
                'id'    => 'private_store_form',
                'desc'  => __( 'Use the settings below to customise the login form displayed to users when the store is locked.', 'woocommerce-private-store' )
            ),
            array(
                'title'    => __( 'Page title', 'woocommerce-private-store' ),
                'desc_tip' => __( 'The title of the page where the user will login.', 'woocommerce-private-store' ),
                'id'       => 'wcps_login_title',
                'type'     => 'text',
                'default'  => __( 'Store Login', 'woocommerce-private-store' )
            ),
            array(
                'title'             => __( 'Message', 'woocommerce-private-store' ),
                'id'                => 'wcps_form_message',
                'type'              => 'textarea',
                'class'             => 'wide-input',
                'custom_attributes' => array( 'cols' => 20, 'rows' => 3 ),
                'default'           => __( 'Enter your password to login:', 'woocommerce-private-store' ),
                'desc'              => __( 'Customise the wording displayed on the store login page.', 'woocommerce-private-store' ),
                'desc_tip'          => true
            ),
            array(
                'title'    => __( 'Password label', 'woocommerce-private-store' ),
                'id'       => 'wcps_form_password_label',
                'type'     => 'text',
                'desc_tip' => __( 'The label shown next to the password box.', 'woocommerce-private-store' ),
                'default'  => __( 'Password:', 'woocommerce-private-store' )
            ),
            array(
                'title' => __( 'Placeholder', 'woocommerce-private-store' ),
                'desc'  => __( 'Use the label as a placeholder for the password input?', 'woocommerce-private-store' ),
                'id'    => 'wcps_form_label_placeholder',
                'type'  => 'checkbox'
            ),
            array(
                'title'    => __( 'Login button', 'woocommerce-private-store' ),
                'id'       => 'wcps_form_button',
                'type'     => 'text',
                'desc_tip' => __( 'Customise the button text on the login form.', 'woocommerce-private-store' ),
                'default'  => __( 'Login', 'woocommerce-private-store' )
            ),
            array(
                'type' => 'sectionend',
                'id'   => 'private_store_form'
            )
        ); // settings array

        $settings[] = array(
            'id'   => 'private_store_settings_end',
            'type' => 'settings_end'
        );

        return \apply_filters( 'woocommerce_get_settings_' . $this->id, $settings );
    }

    public function sanitize_options( $value, $option, $raw_value ) {
        if ( empty( $option['id'] ) ) {
            return $value;
        }

        switch ( $option['id'] ) {
            case $this->license_setting->get_license_setting_name():
                $value = $this->license_setting->save_license_key( $value );
                break;
            case 'wcps_store_password':
                // Remove blank passwords
                $value = \array_filter( $value );
                break;
            case 'wcps_store_redirect':
                if ( $value && ! \filter_var( $value, \FILTER_VALIDATE_URL ) ) {
                    if ( \class_exists( '\WC_Admin_Settings' ) ) {
                        \WC_Admin_Settings::add_error( __( 'The store redirect URL is invalid.', 'woocommerce-private-store' ) );
                    }
                    $value = '';
                }
                break;
            case 'wcps_password_expires':
                if ( empty( $value ) ) {
                    $value = 10;
                }
                break;
        }

        return $value;
    }

}
