<?php

namespace Barn2\Plugin\WC_Private_Store\Admin;

use Barn2\WPS_Lib\Registerable,
    Barn2\WPS_Lib\Service,
    Barn2\WPS_Lib\Plugin\Licensed_Plugin,
    Barn2\WPS_Lib\Util as Lib_Util,
    Barn2\WPS_Lib\Plugin\Admin\Admin_Links;

/**
 * General admin functions for WooCommerce Private Store.
 *
 * @package   Barn2/woocommerce-private-store
 * @author    Barn2 Plugins <info@barn2.co.uk>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Admin_Controller implements Registerable, Service {

    private $plugin;

    public function __construct( Licensed_Plugin $plugin ) {
        $this->plugin      = $plugin;
        $this->admin_links = new Admin_Links( $plugin );
    }

    public function register() {
        $this->admin_links->register();

        // Add settings page.
        \add_filter( 'woocommerce_get_settings_pages', array( $this, 'add_settings_page' ), 20 );

        // Load admin scripts.
        \add_action( 'admin_enqueue_scripts', array( $this, 'load_scripts' ) );
    }

    public function add_settings_page( $settings ) {
        $settings_page = new Settings_Page( $this->plugin );
        $settings_page->register();

        $settings[] = $settings_page;
        return $settings;
    }

    public function load_scripts( $hook ) {
        if ( 'woocommerce_page_wc-settings' !== $hook ) {
            return;
        }

        $min = Lib_Util::get_script_suffix();

        \wp_enqueue_style( 'wcps-admin', $this->plugin->get_dir_url() . "assets/css/admin/wcps-admin{$min}.css", array(), $this->plugin->get_version() );
        \wp_enqueue_script( 'wcps-admin', $this->plugin->get_dir_url() . "assets/js/admin/wcps-admin{$min}.js", array( 'jquery' ), $this->plugin->get_version(), true );

        \wp_localize_script( 'wcps-admin', 'wcps_params', array(
            'confirm_delete' => __( 'Are you sure you want to delete this password?', 'woocommerce-private-store' )
        ) );
    }

}
