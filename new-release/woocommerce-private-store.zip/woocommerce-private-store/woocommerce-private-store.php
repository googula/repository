<?php

/**
 * The main plugin file for WooCommerce Private Store.
 *
 * @package   Barn2/woocommerce-private-store
 * @author    Barn2 Plugins <info@barn2.co.uk>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 *
 * @wordpress-plugin
 * Plugin Name:     WooCommerce Private Store
 * Plugin URI:      https://barn2.co.uk/wordpress-plugins/woocommerce-private-store/
 * Description:     Hide your entire WooCommerce store from the public. Login with a simple password or user account.
 * Version:         1.6.3
 * Author:          Barn2 Plugins
 * Author URI:      https://barn2.co.uk
 * Text Domain:     woocommerce-private-store
 * Domain Path:     /languages
 *
 * WC requires at least: 3.5
 * WC tested up to: 4.3
 *
 * Copyright:       Barn2 Media Ltd
 * License:         GNU General Public License v3.0
 * License URI:     http://www.gnu.org/licenses/gpl-3.0.html
 */
namespace Barn2\Plugin\WC_Private_Store;

// Prevent direct access.
if ( ! \defined( 'ABSPATH' ) ) {
    exit;
}

const PLUGIN_VERSION = '1.6.3';
const PLUGIN_FILE    = __FILE__;

// Include autoloader.
require_once __DIR__ . '/vendor/autoload.php';

/**
 * Helper function to access the shared plugin instance.
 *
 * @return Plugin
 */
function wps() {
    return Plugin_Factory::create( PLUGIN_FILE, PLUGIN_VERSION );
}

/**
 * @deprecated 1.6.2 Replaced by Barn2\Plugin\WC_Private_Store\wps()
 * @return Plugin
 */
function wc_private_store() {
    _deprecated_function( __FUNCTION__, '1.6.2', 'Barn2\\Plugin\\WC_Private_Store\\wps()' );
    return wps();
}

// Load the plugin.
wps()->register();
