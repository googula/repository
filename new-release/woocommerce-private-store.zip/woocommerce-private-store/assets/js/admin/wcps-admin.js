
(function( $ ) {
    "use strict";

    if ( 'selectWoo' in $.fn ) {
        $( '#wcps_logged_in_roles' ).selectWoo( { placeholder: 'All roles' } );
    }

    var $multi_text_fields = $( '.private-store-settings .multi-field-container' );

    $multi_text_fields.on( 'click', '.multi-field-actions a', function() {
        var action = $( this ).data( 'action' );

        if ( 'add' === action ) {
            // Add text field
            var $container = $( this ).parents( '.multi-field-container' );
            var $field_copy = $container.children( '.multi-field-input' ).first().clone();

            $field_copy.children( '.multi-field-actions' ).append( '<a class="multi-field-remove" data-action="remove" href="#"><span class="dashicons dashicons-minus"></span></a>' );
            $field_copy.find( 'input' ).attr( 'value', '' ).removeAttr( 'id' );
            $field_copy.appendTo( $container );

        } else if ( 'remove' === action ) {
            // Remove text field
            var $field = $( this ).parents( '.multi-field-input' );
            var value = $field.find( 'input' ).val();

            // Remove if nothing entered or if user confirms deletion
            if ( !value || confirm( wcps_params.confirm_delete ) ) {
                $field.remove();
            }
        }

        return false;
    } );

    var toggleChildSettings = function( $parent, $children ) {
        var show = false;

        if ( 'checkbox' === $parent.attr( 'type' ) ) {
            show = $parent.prop( 'checked' );
        }

        $children.toggle( show );
    };

    $( '.private-store-settings .toggle-parent' ).each( function() {
        var $parent = $( this );
        var $children = $parent.closest( '.form-table' ).find( '.' + $parent.data( 'childClass' ) ).closest( 'tr' );

        toggleChildSettings( $parent, $children );

        $parent.on( 'change', function() {
            toggleChildSettings( $parent, $children );
        } );
    } );

})( jQuery );
