<?php

/**
 * No Discussions Feedback Part
 *
 * @package BuddyBoss\Theme
 */

?>

<br />
<div class="bp-feedback info">
	<span class="bp-icon" aria-hidden="true"></span>
	<p><?php _e( 'Sorry, there were no discussions found.', 'buddyboss' ); ?></p>
</div>
