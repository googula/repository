<?php get_header(); ?>
<!-- layout -->
<div id="layout" class="pagewidth tf_clearfix">
    <?php themify_content_before(); //hook ?>
    <!-- content -->
    <main id="content" class="tf_clearfix">
	<?php themify_page_output(); ?>
    </main>
    <!-- /#content -->
    <?php themify_content_after() //hook; ?>
    <?php themify_get_sidebar(); ?>
</div>
<!-- /#layout -->	
<?php
get_footer();
