<?php query_posts("post_type=slider&showposts=-1"); ?>	
<?php
if (have_posts()) :
	$autoplay = themify_get( 'setting-feature_box_auto', '0',true );
	$speed = themify_get( 'setting-feature_box_speed', 1000,true );
	$config = array(
		'data-lazy'        => 1,
		'data-auto'        => $autoplay !== '0' ? $autoplay : false,
		'data-effect'      => themify_get( 'setting-feature_box_effect', 'slide', true ),
		'data-speed'       => $speed < 1000 ? $speed / 1000 : $speed,
		'data-pager'       => 0,
		'data-slider_nav'  => 1,
	);
?>
	<div id="slider" class="pagewidth slider tf_overflow tf_clearfix tf_rel">

		<?php themify_slider_before(); //hook ?>

		<div <?php echo themify_get_element_attributes( $config ); ?> class="tf_carousel swiper-container">

			<?php themify_slider_start(); //hook ?>

			<div class="swiper-wrapper">

				<?php while (have_posts()) : the_post(); ?>
					<?php $content = themify_get('layout');?>
					<div <?php post_class(array($content,'tf_lazy swiper-slide')); ?>>

					<?php 
					$before = '';
					$after = '';
					$link = themify_permalink_attr(array('no_permalink'=>true),false); 
					$link=$link['href'];
					if( $link != ''){
					$before = '<a href="'. $link .'" title="'. the_title_attribute('echo=0') . '">';
					$after = themify_zoom_icon(false) . '</a>' . $after;
					}  				  
					if($content === 'slider-image-only'){

					echo $before , themify_get_image(array('w'=>978,'h'=>400,'is_slider'=>true)), $after;

					} elseif($content === 'slider-content-only'){

					the_content();

					} else if($content=== 'slider-image-caption'){

					echo '<div class="image-caption-wrap">';
						echo $before , themify_get_image(array('w'=>978,'h'=>400,'is_slider'=>true)), $after;
						echo '<div class="caption">';
							echo '<h3>' . $before . get_the_title() . $after . '</h3>';
							the_content();
						echo '</div>';
					echo '</div>';

					} else {

					echo $before ,themify_get_image(array('w'=>470,'h'=>400,'is_slider'=>true,'class'=>'slide-feature-image')), $after;
					echo '<div class="slide-content">';
						echo '<h3>' . $before . get_the_title() . $after . '</h3>';
						the_content();
					echo '</div>';
					}
					?>

					</div>
				<?php endwhile; ?>

			</div><!-- .swiper-wrapper -->

		</div><!-- .swiper-container -->

		<?php themify_slider_after(); //hook ?>

	</div><!--/slider --> 
<?php endif; ?>
<?php wp_reset_query(); 
