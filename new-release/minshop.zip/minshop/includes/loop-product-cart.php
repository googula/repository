<?php
	global $woocommerce,$product;
	$carts = array_reverse($woocommerce->cart->get_cart());
	$isNew=function_exists('wc_get_cart_remove_url');
	if ( isset( $product ) && is_object( $product ) ) {
		$_post = clone $product;
	}
foreach ($carts as $key => $cart_item) :
	
	// Add support for MNM plugin
	if( isset( $cart_item['mnm_container'] ) ||  $cart_item['quantity']<=0) continue;
	
		$product  = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $key );
		if ($product->exists() &&  apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $key ) ):
			$product_permalink=apply_filters( 'woocommerce_cart_item_permalink', $product->is_visible() ? $product->get_permalink( $cart_item ) : '', $cart_item, $key );
			$hasLink=!empty($product_permalink);
		?>

	<div class="product">

		<a href="<?php echo $isNew===true? wc_get_cart_remove_url( $key ) : $woocommerce->cart->get_remove_url( $key ); ?>" data-product-key="<?php echo $key; ?>" class="remove-item remove-item-js"><?php _e('Remove','themify')?></a>
		<figure class="product-image">
			<?php themify_product_cart_image_start(); //hook ?>
			<?php if($hasLink===true):?>
				<a href="<?php echo esc_url($product_permalink) ?>">
			<?php endif;?>
				<?php
					$product_thumbnail =$product_thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $product->get_image('woocommerce_thumbnail',array('loading'=>'lazy','decode'=>'async')), $cart_item, $key );
					if ( ! empty( $product_thumbnail ) ) {
						echo $product_thumbnail;
					} else {
						?>
						<img src="http://placehold.it/65x65">
						<?php
					}
				?>
			<?php if($hasLink===true):?>
				</a>
			<?php endif;?>
			<?php themify_product_cart_image_end(); //hook ?>
		</figure>
		<div class="product-details">
			<h3 class="product-title">
				<?php if($hasLink===true):?>
					<a href="<?php echo esc_url($product_permalink) ?>">
				<?php endif;?>
					<?php echo apply_filters( 'woocommerce_cart_item_name', $product->get_name(), $cart_item, $key ); ?>
				<?php if($hasLink===true):?>
					</a>
				<?php endif;?>
			</h3>
			<p class="quantity-count"><?php echo sprintf(__('x %d', 'themify'), $cart_item['quantity']); ?></p>
		</div>

	</div>
	<!--/product -->

	<?php endif;
endforeach;

if(isset($_post)){
	$product=clone $_post;
	unset($_post);
}
else{
	unset($product);
}