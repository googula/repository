<?php
/**
 * WooCommerce Template Override
 * woocommerce-template.php
 */

if(!function_exists('themify_before_shop_content')) {
	/**
	 * Add initial portion of wrapper
	 */
	function themify_before_shop_content() { ?>
		<!-- layout -->
		<div id="layout" class="pagewidth tf_clearfix">
			
			<?php themify_content_before(); //hook ?>
			<!-- content -->
			<main id="content" class="<?php echo (is_product() || themify_is_shop()) ? 'list-post':''; ?>">
				
				<?php if( ! ( themify_check( 'setting-hide_shop_breadcrumbs',true ) 
					|| ( themify_check( 'setting-hide_shop_single_breadcrumbs',true ) && is_product() ) ) ) { ?>
				
					<?php themify_breadcrumb_before(); ?>
					
					<?php woocommerce_breadcrumb(); ?>
					
					<?php themify_breadcrumb_after(); ?>
					
				<?php } ?>
				
				<?php themify_content_start(); //hook ?>
				
				<?php
	}
}

if(!function_exists('themify_after_shop_content')) {
	/**
	 * Add end portion of wrapper
	 */
	function themify_after_shop_content() {
				if (is_search() && is_post_type_archive() ) {
					add_filter( 'woo_pagination_args', 'woocommerceframework_add_search_fragment', 10 );
				} ?>
				<?php themify_content_end(); //hook ?>
			</main>
			<!-- /#content -->
			 <?php themify_content_after() //hook; ?>

			<?php themify_get_sidebar();?>
		</div><!-- /#layout -->
		<?php
	}
}

if (!function_exists('woocommerce_single_product_content_ajax')) {
	/**
	 * WooCommerce Single Product Content with AJAX
	 * @param object|bool $wc_query
	 */
	function woocommerce_single_product_content_ajax( $wc_query = false ) {

		// Override the query used
		if (!$wc_query) {
			global $wp_query;
			$wc_query = $wp_query;
		}
		
		if ( $wc_query->have_posts() ){
                   
                    while ( $wc_query->have_posts() ) : $wc_query->the_post(); ?>
			<div id="product_single_wrapper" class="product product-<?php the_ID(); ?> single product-single-ajax">
				<div class="product-imagewrap">
					<?php do_action('themify_single_product_image_ajax'); ?>
				</div>
				<div class="product-content product-single-entry">
					<h3 class="product-title"><?php the_title(); ?></h3>
					<div class="product-price">
						<?php do_action('themify_single_product_price'); ?>
					</div>
					<?php do_action('themify_single_product_ajax_content'); ?>
				</div>
			</div>
			<!-- /.product -->
		<?php endwhile;
                 wc_get_template( 'single-product/add-to-cart/variation.php' );
                }
	}
}

if(!function_exists('themify_product_image_ajax')){
	/**
	 * Filter image of product loaded in lightbox to remove link and wrap in figure.product-image. Implements filter themify_product_image_ajax for external usage
	 * @param string $html Original markup
	 * @param int $post_id Post ID
	 * @return string Image markup without link
	 */
	function themify_product_image_ajax($html, $post_id) {
		$image = get_the_post_thumbnail( $post_id, apply_filters( 'single_product_large_thumbnail_size', 'shop_single' ) );
		return apply_filters( 'themify_product_image_ajax', sprintf( '<figure class="product-image">%s<span class="loading-product"></span></figure>', $image ) );
	}
}

if(!function_exists('themify_product_image_single')){
	/**
	 * Filter image of product loaded in lightbox to remove link and wrap in figure.product-image. Implements filter themify_product_image_ajax for external usage
	 * @param string $html Original markup
	 * @param int $post_id Post ID
	 * @return string Image markup without link
	 */
	function themify_product_image_single($html, $post_id) {
		//$html = str_replace('</a>', '<span class="loading-product"></span></a>', $html);
		//<figure class="product-image">%s</figure>
		$pattern = '/(<img(.*)>)<\/a>/i';
		$replacement = '<figure class="product-image">${1}<span class="loading-product"></span></figure></a>';
		$html = preg_replace($pattern, $replacement, $html);
		return $html;
	}
}

if(!function_exists('themify_loop_add_to_cart_link')) {
	/**
	 * Filter link to setup lightbox capabilities
	 * @param string $format Original markup
	 * @param object $product WC Product Object
	 * @param array $link Array of link parameters
	 * @return string Markup for link
	 */
	function themify_loop_add_to_cart_link( $format = '', $product = null, $link = array() ) {
		$type=$product->get_type();
		if('variable' === $type || 'grouped' === $type) {
			$url = add_query_arg( array('ajax' => 'true', 'width' => '616', 'height' => '326'), $product->add_to_cart_url() );
			$replacement = 'class="variable-link '; // add space at the end
			$format = preg_replace( '/(class=")/', $replacement, $format, 1 );
			$format = preg_replace( '/href="(.*?)"/', 'href="'.$url.'"', $format, 1 );
		}

		if ( $product->is_purchasable() ) {
			$format = preg_replace( '/add_to_cart_button/', 'add_to_cart_button theme_add_to_cart_button', $format, 1 );
		}
		return $format;
	}
}

if(!function_exists('themify_product_description')){
	/**
	 * WooCommerce Single Product description
	 */
	function themify_product_description(){
		the_content();
	}
}

if(!function_exists('themify_shopdock_bar')){
	/**
	 * Load dock bar in footer
	 */
	function themify_shopdock_bar(){
		get_template_part('includes/shopdock');
	}
}

if(!function_exists('themify_redirect_product_ajax_content')){
	/**
	 * Single product lightbox
	 **/
	function themify_redirect_product_ajax_content() {
		global $wp_query;
		// locate template single page in lightbox
		if (is_single() && isset($_GET['ajax']) && $_GET['ajax']) {
			add_filter('woocommerce_single_product_image_html', 'themify_product_image_ajax', 10, 2);
		    // remove admin bar inside iframe
			add_filter( 'show_admin_bar', '__return_false' );
			if (have_posts()) {
				woocommerce_single_product_content_ajax();
				die();
			} else {
				$wp_query->is_404 = true;
			}
		}
	}
}

if (!function_exists('themify_theme_wc_loading_product')) {
    /**
     * Product loading icon
     **/
    function themify_theme_wc_loading_product() {
        echo '<span class="loading-product"></span>';
    }
}