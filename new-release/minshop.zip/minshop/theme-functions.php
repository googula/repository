<?php
/*
To add custom PHP functions to the theme, create a child theme (https://themify.me/docs/child-theme) and add it to the child theme functions.php file. 
They will be added to the theme automatically.
*/


function themify_theme_google_fonts( $fonts ) {
	$fonts['cambo'] = 'Cambo';
	return $fonts;
}
add_filter( 'themify_google_fonts', 'themify_theme_google_fonts' );

add_filter('themify_register_sidebars','themify_theme_register_sidebars');

// Slider Post Type
register_post_type('slider', array(
	'labels' =>  array(
		'name' => __( 'Slides', 'themify' ),
		'singular_name' => __( 'Slide', 'themify' ),
		'add_new' => __( 'Add New Slide', 'themify' ),
		'add_new_item' => __( 'Add New Slide', 'themify' ),
		'edit_item' => __( 'Edit Slide', 'themify' ),
		'new_item' => __( 'New Slide', 'themify' ),
		'view_item' => __( 'View Slide', 'themify' ),
		'search_items' => __( 'Search Slides', 'themify' ),
		'not_found' => __( 'No slides found', 'themify' ),
		'not_found_in_trash' => __( 'No slides found in Trash', 'themify' ),
		'parent_item_colon' => __( 'Parent Slider:', 'themify' ),
		'menu_name' => __( 'Slider', 'themify' ),
	),
	'description' => "",
	'menu_position' => 5,
	'public' => true,
	'show_ui' => true,
	'capability_type' => 'post',
	'hierarchical' => false,
	'rewrite' => false,
	'query_var' => false,
	'supports' => array('title', 'editor', 'author', 'custom-fields')
));



///////////////////////////////////////
// Register Custom Menu Function
///////////////////////////////////////
function themify_register_custom_nav() {

    /* prevent update checks from wp.org repository */
    add_theme_support( 'themify-exclude-theme-from-wp-update' );
    
    add_theme_support( 'post-thumbnails' );

    // Declare Woocommerce support
    add_theme_support( 'woocommerce' );
    
    register_nav_menus( array(
	    'main-nav' => __( 'Main Navigation', 'themify' ),
	    'footer-nav' => __( 'Footer Navigation', 'themify' ),
    ) );
}

// Register Custom Menu Function - Action
add_action('after_setup_theme', 'themify_register_custom_nav');

/* 
 * Register sidebars
 * @since 1.0.0
 */
function themify_theme_register_sidebars($sidebars) {
    
    $sidebars[]=array(
	    'name' => __('Header Widget', 'themify'),
	    'id' => 'header-widget',
	    'before_widget' => '<div id="%1$s" class="widget %2$s">',
	    'after_widget' => '</div>',
	    'before_title' => '<strong>',
	    'after_title' => '</strong>'
    );
    return $sidebars;
     
}

// Exclude CPT for sidebar
add_filter( 'themify_exclude_CPT_for_sidebar', 'themify_CPT_exclude_sidebar' );

if( ! function_exists('themify_CPT_exclude_sidebar') ) {
	/**
	 * Exclude Custom Post Types
	 */
	function themify_CPT_exclude_sidebar($CPT = array()) {
		$CPT[]='slider';
		if(themify_is_woocommerce_active()){
			$CPT[] = 'product';
		}
		return $CPT;
	}
}

add_action( 'themify_layout_before', 'themify_theme_layout_before' );

if ( ! function_exists( 'themify_get_ecommerce_template' ) ) {
	/**
	 * Checks if Woocommerce is active and loads the requested template
	 * @param string $template
	 * @since 1.3.1
	 */
	function themify_get_ecommerce_template( $template = '' ) {
		if ( themify_is_woocommerce_active() )
			get_template_part( $template );
	}
}

/**
 * Include slider and, if Woocommerce is active, product slider
 * @since 1.3.1
 */
function themify_theme_layout_before() {
	if(is_front_page() && !is_paged()){ 
	    get_template_part( 'includes/slider'); 
	    themify_get_ecommerce_template( 'includes/product-slider'); 
	}
}
if(!function_exists('themify_theme_wc_variable_product_data')){
    function themify_theme_wc_variable_product_data($params,$handle){
        if($handle==='wc-add-to-cart-variation'){
            wp_dequeue_script( 'wc-add-to-cart-variation');
            remove_filter('woocommerce_get_script_data','themify_theme_wc_variable_product_data',10,2);
            wp_localize_script( 'themify-main-script', 'wc_add_to_cart_variation_params', $params );
        }
        return $params;
    }
}
// Load required files
if ( themify_is_woocommerce_active() ) {
	require_once(TEMPLATEPATH . '/woocommerce/theme-woocommerce.php'); // WooCommerce overrides
	require_once(TEMPLATEPATH . '/woocommerce/woocommerce-hooks.php'); // WooCommerce hook overrides
	require_once(TEMPLATEPATH . '/woocommerce/woocommerce-template.php'); // WooCommerce template overrides
	function themify_theme_enqueue_footer() {
	    //Themify shop script
	    Themify_Enqueue_Assets::addPreLoadJs(THEME_URI . '/js/themify.shop.js',Themify_Enqueue_Assets::$themeVersion);

	    //Inject variable values in themify.shop.js
	    $themify_script_vars = array(
			    'redirect'=> get_option( 'woocommerce_cart_redirect_after_add' ) === 'yes'?wc_get_cart_url():false
	    );
        if(!themify_check( 'setting-optimize-wc', true )){
            add_filter('woocommerce_get_script_data','themify_theme_wc_variable_product_data',10,2);
        }
	    // Pass variable values to JavaScript
	    wp_localize_script( 'themify-main-script', 'themifyScript', apply_filters( 'themify_script_vars', $themify_script_vars ) );

	}
}