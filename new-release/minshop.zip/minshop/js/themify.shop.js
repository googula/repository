; //defensive semicolon
(function ($) {
    'use strict';
    $.fn.serializeObject = function () {
        var o = {};
        var a = this.serializeArray();
        $.each(a, function () {
            if (o[this.name] !== undefined) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };

    /////////////////////////////////////////////
    // Toggle Cart
    /////////////////////////////////////////////
    Themify.body.on('click', '#cart-tag', function (e) {
        e.preventDefault();
        $('#cart-wrap').css('visibility', 'visible').fadeToggle();
    }).on("click", '.sort-by', function (e) {
        e.preventDefault();
        if ($(this).next().is(':visible')) {
            $(this).next().slideUp();
            $(this).removeClass('active');
        }
        else {
            $(this).next().slideDown();
            $(this).addClass('active');
        }

    }).on("mouseenter", '.orderby-wrap', function (e) {
        if (!$(this).find('.orderby').is(':visible')) {
            $(this).find('.orderby').slideDown();
            $(this).find('.sort-by').addClass('active');
        }
        else if (e.type === 'mouseleave' && $(this).find('.orderby').is(':visible') && $(this).find('.sort-by').hasClass('active')) {
            $(this).find('.orderby').slideUp();
            $(this).find('.sort-by').removeClass('active');
        }
        e.preventDefault();
    }).on("mouseleave", '.orderby-wrap', function (e) {
        if ($(this).find('.orderby').is(':visible') && $(this).find('.sort-by').hasClass('active')) {
            $(this).find('.orderby').slideUp();
            $(this).find('.sort-by').removeClass('active');
        }
        e.preventDefault();
    });

    /*function ajax add to cart in single page */
    function ajax_add_to_cart_single_page() {
        $(document).on('submit', 'form.cart', function (e) {
            if ( $( this ).closest( '.product-type-external' ).length ) {
                return;
            }
            e.preventDefault();
            var data = $(this).serializeObject(),
                data2 = {action: 'theme_add_to_cart'};
            if($(this).find('input[name="add-to-cart"]').length===0){
                data2['add-to-cart'] = $(this).find('[name="add-to-cart"]').val();
            }
            $.extend(true, data, data2);

            // Trigger event
            Themify.body.triggerHandler('adding_to_cart', [$(this), data]);

            // Ajax action
            $.post(woocommerce_params.ajax_url, data, function (response) {

                if (!response){
                    return;
                }
                if (themifyScript.redirect) {
                    window.location.href = themifyScript.redirect;
                    return;
                }
                var fragments = response.fragments,
                    cart_hash = response.cart_hash;

                // Replace fragments
                if (fragments) {
                    $.each(fragments, function (key, value) {
                        $(key).addClass('updating').replaceWith(value);
                    });
                }
                // Trigger event so themes can refresh other areas
                Themify.body.triggerHandler('added_to_cart', [fragments, cart_hash]);

            });
        });
    }

    /////////////////////////////////////////////
    // Add to cart ajax
    /////////////////////////////////////////////
    if (typeof wc_add_to_cart_params!=='undefined') {

        // Ajax add to cart
        var $loadingIcon;
        Themify.body.on('adding_to_cart', function (e, $button, data) {
            // hide cart wrap
            $('#cart-wrap').hide();
            $('#cart-loader').addClass('loading');
            // This loading icon
            $loadingIcon = $('.loading-product', $button.closest('.product')).first();
            $loadingIcon.show();
        }).on('added_to_cart removed_from_cart', function (e, fragments, cart_hash) {

            if (typeof $loadingIcon !== 'undefined') {
                // Hides loading animation
                $loadingIcon.hide(300, function () {
                    $(this).addClass('loading-done');
                });
                $loadingIcon
                    .fadeIn()
                    .delay(500)
                    .fadeOut(300, function () {
                        $(this).removeClass('loading-done');
                    });
				$loadingIcon = undefined;
            }

            // close lightbox
            if ($('.mfp-content.themify_product_ajax').is(':visible')) {
                $.magnificPopup.close();
            }
        });

        // remove item ajax
        $(document).on('click', '.remove-item-js', function () {
            $('#cart-loader').addClass('loading');

            // AJAX add to cart request
            var $thisbutton = $(this),
                data = {
                    action: 'theme_delete_cart',
                    remove_item: $thisbutton.attr('data-product-key')
                };

            // Ajax action
            $.post(woocommerce_params.ajax_url, data, function (response) {
                var fragments = response.fragments,
                    cart_hash = response.cart_hash;
                // Changes button classes
                if ($thisbutton.parent().find('.added_to_cart').size() == 0)
                    $thisbutton.addClass('added');

                // Replace fragments
                if (fragments) {
                    $.each(fragments, function (key, value) {
                        $(key).addClass('updating').replaceWith(value);
                    });
                }
                // Trigger event so themes can refresh other areas
                Themify.body.triggerHandler('removed_from_cart', [fragments, cart_hash]);

            });

            return false;
        });

        // Ajax add to cart in single page
        ajax_add_to_cart_single_page();

    }

    /* function ajax variation callback */
    function ajax_variation_callback() {
        const forms = $('.variations_form');
        if(forms.length>0){
            forms.closest('#product_single_wrapper').find('.woocommerce-product-gallery .woocommerce-product-gallery__image a').on('click', function(e){e.stopPropagation(); return false;});
            Themify.trigger('tf_wc_init', true);
        }
    }

    function lightboxCallback(context) {
        $("a.variable-link", context).each(function () {
            $(this).magnificPopup({
                type: 'ajax',
                callbacks: {
                    updateStatus: function (data) {
                        ajax_variation_callback();
                        $('.mfp-content').addClass('themify_product_ajax themify_variable_product_ajax');
                    }
                }
            });
        });
    }
    // ajax variation lightbox
    function ajax_variation_lightbox(context) {
        if ($("a.variable-link", context).length > 0) {
            Themify.LoadCss(Themify.url + '/css/lightbox.css', null);
            Themify.LoadAsync(Themify.url + '/js/lightbox.min.js', function () {
                lightboxCallback(context)
                return ('undefined' !== typeof $.fn.magnificPopup);
            });
        }
    }
    // Initial ajax variation lightbox
    ajax_variation_lightbox(document);

    // reply review
    $('.reply-review').on('click',function () {
        $('#respond').slideToggle('slow');
        return false;
    });

    // add review
    $('.add-reply-js').on('click',function () {
        $(this).hide();
        $('#respond').slideDown('slow');
        $('#cancel-comment-reply-link').show();
        return false;
    });
    $('#reviews #cancel-comment-reply-link').on('click',function () {
        $(this).hide();
        $('#respond').slideUp();
        $('.add-reply-js').show();
        return false;
    });

    /**
     * Limit the number entered in the quantity field.
     * @param $obj The quantity field object.
     * @param max_qty The max quantity allowed per the inventory current stock.
     */
    function limitQuantityByInventory($obj, max_qty) {
        var qty = $obj.val();
        if (qty > max_qty) {
            $obj.val(max_qty);
        }
    }

    // Limit number entered manually in quantity field in single view
    if (Themify.body.hasClass('single-product')) {
        $('.entry-summary').on('keyup', 'input[name="quantity"][max]', function () {
            limitQuantityByInventory($('input[name="quantity"]'), parseInt($(this).attr('max'), 10));
        });
    }

    $(document).on('click', '.plus, .minus', function () {

        // Get values
        var $qty = $(this).closest('.quantity').find('.qty'),
            currentVal = parseFloat($qty.val()),
            max = parseFloat($qty.prop('max')),
            min = parseFloat($qty.prop('min')),
            step = parseFloat($qty.prop('step'));

        // Format values
        if (!currentVal) {
            currentVal = 1;
        }
        if (!max) {
            max = false;
        }
        if (!min) {
            min = false;
        }
        if (!step) {
            step = 1;
        }
        // Change the value
        if ($(this).hasClass('plus')) {
            currentVal = max && currentVal >= max ? max : currentVal + step;
        } else {
            currentVal = min && currentVal <= min ? min : (currentVal > step ? currentVal - step : currentVal);
        }
        // Trigger change event
        $qty.val(currentVal).trigger('change');
    }).on('keyup', 'form.cart input[name="quantity"]', function () {
        var $max = parseFloat($(this).prop('max'));
        if ($max > 0) {
            limitQuantityByInventory($(this), parseInt($max, 10));
        }
    });

}(jQuery));
