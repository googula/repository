;
(function($,Themify) {
    'use strict';
		
	/////////////////////////////////////////////
	// Scroll to top 							
	/////////////////////////////////////////////
	$('.back-top a').on('click',function (e) {
            e.preventDefault();
            Themify.scrollTo();
	});
	
	/////////////////////////////////////////////
	// Toggle menu on mobile 							
	/////////////////////////////////////////////
	$("#menu-icon").on('click',function(){
            $("#main-nav").fadeToggle();
            $("#headerwrap #searchform").hide();
            $(this).toggleClass("active");
	});

	/////////////////////////////////////////////
	// Toggle searchform on mobile 							
	/////////////////////////////////////////////
	$("#search-icon").on('click',function(){
            $("#headerwrap #searchform").fadeToggle();
            $("#headerwrap #main-nav").hide();
            $(this).toggleClass("active");
	});
	
	// Show/Hide search form and unfold/fold search options
	$('#headerwrap #searchform').on('touchend mouseenter', function() {
		$('#s',this).stop().animate({
			width : 140
		}, {
			queue : false,
			duration : 300,
                        easing: 'easeInOutCubic'
		});
		$('.search-option',this).css('visibility', 'visible').stop().animate({
			opacity : 1,
			height : 21,
			left : 0,
			width : 117
		}, {
			queue : false,
			duration : 500,
			easing: 'easeInOutCubic'
		});
	})
        .on('mouseleave', function() {
		$('#s',this).stop().animate({
			width : '55'
		}, {
			queue : false,
			duration : 200
		});
		$('.search-option',this).stop().animate({
			opacity : 0,
			height : '0',
			left : 117,
			width : 0
		}, {
			queue : false,
			duration : 200
		});	
	})
        .find('.search-option').each(function(){
		$('input', $(this)).on('change',function(e){
                    $(this).parent().siblings('.search-type').val( $(this).val() );
		});
	});
	if(window['woocommerce_params']!==undefined){
		Themify.LoadAsync(themify_vars.theme_url + '/js/themify.shop.js',null, themify_vars.theme_v);
	}

}(jQuery,Themify));
