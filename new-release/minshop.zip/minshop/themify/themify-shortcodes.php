<?php

/**
 * Deprecated. Please use Themify Shortcodes plugin: https://wordpress.org/plugins/themify-shortcodes/
 * Keep this file for backwards compatibility.
 */