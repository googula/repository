<?php

// Slider Meta Box Options
if (!function_exists('themify_theme_slider_meta_box')) {

    function themify_theme_slider_meta_box() {
	return array(
	    // Post Layout
	    array(
		'name' => 'layout',
		'title' => __('Slide Layout', 'themify'),
		'description' => '',
		'type' => 'layout',
		'show_title' => true,
		'meta' => array(
		    array('value' => 'slider-default', 'img' => 'images/layout-icons/slider-default.png', 'selected' => true, 'title' => __('Default', 'themify')),
		    array('value' => 'slider-image-only', 'img' => 'images/layout-icons/slider-image-only.png', 'title' => __('Image Only', 'themify')),
		    array('value' => 'slider-content-only', 'img' => 'images/layout-icons/slider-content-only.png', 'title' => __('Content Only', 'themify')),
		    array('value' => 'slider-image-caption', 'img' => 'images/layout-icons/slider-image-caption.png', 'title' => __('Image Caption', 'themify'))
		)
	    ),
	    // Feature Image
	    array(
		'name' => 'feature_image',
		'title' => __('Featured Image', 'themify'), //slider image
		'description' => '',
		'type' => 'image',
		'meta' => array()
	    ),
	    // Featured Image Size
	    array(
		'name' => 'feature_size',
		'title' => __('Image Size', 'themify'),
		'description' => __('Image sizes can be set at <a href="options-media.php">Media Settings</a> and <a href="https://wordpress.org/plugins/regenerate-thumbnails/" target="_blank">Regenerated</a>', 'themify'),
		'type' => 'featimgdropdown',
		'display_callback' => 'themify_is_image_script_disabled'
	    ),
	    // Image Width
	    array(
		'name' => 'image_width',
		'title' => __('Image Width', 'themify'),
		'description' => '',
		'type' => 'textbox',
		'meta' => array('size' => 'small')
	    ),
	    // Image Height
	    array(
		'name' => 'image_height',
		'title' => __('Image Height', 'themify'),
		'description' => __('Enter height = 0 to disable vertical cropping with img.php enabled', 'themify'),
		'type' => 'textbox',
		'meta' => array('size' => 'small')
	    ),
	    // Image Link
	    array(
		'name' => 'image_link',
		'title' => __('Image Link', 'themify'),
		'description' => '',
		'type' => 'textbox',
		'meta' => array()
	    ),
	    // External Link
	    array(
		'name' => 'external_link',
		'title' => __('External Link', 'themify'),
		'description' => __('Link Featured Image and Post Title to external URL', 'themify'),
		'type' => 'textbox',
		'meta' => array()
	    ),
	    // Lightbox Link + Zoom icon
	    themify_lightbox_link_field()
	);
    }

}
if (!function_exists('themify_theme_get_slider_metaboxes')) {

    function themify_theme_get_slider_metaboxes(array $args, &$meta_boxes) {
	return array(
	    array(
		'name' => __('Homepage Slider Options', 'themify'),
		'id' => 'slider-options',
		'options' => themify_theme_slider_meta_box(),
		'pages' => 'slider'
	    )
	);
    }

}