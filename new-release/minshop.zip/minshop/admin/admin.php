<?php

include THEME_DIR.'/admin/panel/settings.php';

function themify_theme_setup_metaboxes($meta_boxes=array(), $post_type='all') {
    $supportedTypes=array('post', 'page', 'slider');
    $dir=THEME_DIR . '/admin/pages/';
    if($post_type==='all'){
	foreach($supportedTypes as $s){
	    require_once( $dir . "$s.php" );
	}
	return $meta_boxes;
    }
    if (!in_array($post_type,$supportedTypes , true)) {
	return $meta_boxes;
    }
    require_once( $dir . "$post_type.php" );
    $theme_metaboxes = call_user_func_array( "themify_theme_get_{$post_type}_metaboxes", array( array(), &$meta_boxes ) );

    return array_merge($theme_metaboxes, $meta_boxes);
}

if(isset( $_GET['page'] ) && $_GET['page']==='themify'){
    themify_theme_setup_metaboxes();
}
else{
    add_filter('themify_metabox/fields/themify-meta-boxes', 'themify_theme_setup_metaboxes', 10, 2);
}

if ( ! function_exists( 'themify_check_ecommerce_environment_admin' ) ) {
	/**
	 * Check in admin if Woocommerce is enabled and show a notice otherwise.
	 * @since 1.3.0
	 */
	function themify_check_ecommerce_environment_admin() {
		if ( ! themify_is_woocommerce_active() ) {
			$warning = 'installwoocommerce';
			if ( ! get_option( 'themify_warning_' . $warning ) ) {
				wp_enqueue_script( 'themify-admin-warning', themify_enque(THEME_URI . '/admin/js/themify.admin.warning.js'), null, Themify_Enqueue_Assets::$themeVersion, true );
				echo '<div class="update-nag">'.__('Remember to install and activate WooCommerce plugin to enable the shop.', 'themify'). ' <a href="#" class="themify-close-warning" data-warning="' . $warning . '" data-nonce="' . wp_create_nonce( 'themify-warning' ) . '">' . __("Got it, don't remind me again.", 'themify') . '</a></div>';
			}
		}
	}
	add_action( 'admin_notices', 'themify_check_ecommerce_environment_admin' );
}

if ( ! function_exists( 'themify_dismiss_warning' ) ) {
	/**
	 * AJAX - Handle warning dismiss action.
	 */
	function themify_dismiss_warning() {
		check_ajax_referer( 'themify-warning', 'nonce' );
		$result = false;
		if ( isset( $_POST['warning'] ) ) {
			$result = update_option( 'themify_warning_' . $_POST['warning'], true );
		}
		if ( $result ) {
			echo 'true';
		} else {
			echo 'false';
		}
		die;
	}
	add_action( 'wp_ajax_themify_dismiss_warning', 'themify_dismiss_warning' );
}
