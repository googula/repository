<?php
/**
 * Template for comments
 * @package themify
 * @since 1.0.0
 */
themify_comments();