=== WooCommerce Wishlists ===
== Installation ==

1. Upload the folder 'woocommerce-wishlists' to the '/wp-content/plugins/' directory

2. Activate 'WooCommerce Wishlists' through the 'Plugins' menu in WordPress

== Usage == 
See full documentation at the WooThemes documentation site. 